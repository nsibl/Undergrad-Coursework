//Allows file data to be grabbed as string
public interface Printable
{
	//Returns as string
	public String getFileData();
	
}